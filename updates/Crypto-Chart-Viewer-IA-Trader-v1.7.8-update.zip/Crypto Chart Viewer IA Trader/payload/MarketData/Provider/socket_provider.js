'use strict';

/* IA-Trading-Bot v1.7.8
 * Generic SOCKET provider transport.
 * Designed for persistent WebSocket market-data feeds while keeping provider
 * specifics (subscriptions and normalization) outside the transport layer.
 */

var WebSocket = require('ws');

function SocketProvider(options) {
  options = options || {};
  this.name = options.name || 'SOCKET';
  this.url = options.url || '';
  this.protocols = options.protocols;
  this.reconnectMs = Math.max(1000, +(options.reconnectMs || 3000));
  this.maxReconnectMs = Math.max(this.reconnectMs, +(options.maxReconnectMs || 30000));
  this.ws = null;
  this.closedByUser = false;
  this.reconnectTimer = null;
  this.currentReconnectMs = this.reconnectMs;
  this.listeners = { open: [], close: [], error: [], message: [] };
}

SocketProvider.prototype.on = function (event, fn) {
  if (!this.listeners[event] || typeof fn !== 'function') return this;
  this.listeners[event].push(fn);
  return this;
};

SocketProvider.prototype._emit = function (event, payload) {
  var list = this.listeners[event] || [];
  list.forEach(function (fn) {
    try { fn(payload); } catch (_) {}
  });
};

SocketProvider.prototype.connect = function () {
  var self = this;
  if (!this.url) throw new Error('SOCKET_URL_MISSING');
  if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) return;

  this.closedByUser = false;
  this.ws = new WebSocket(this.url, this.protocols);

  this.ws.on('open', function () {
    self.currentReconnectMs = self.reconnectMs;
    self._emit('open');
  });

  this.ws.on('message', function (data) {
    self._emit('message', data);
  });

  this.ws.on('error', function (err) {
    self._emit('error', err);
  });

  this.ws.on('close', function (code, reason) {
    self._emit('close', { code: code, reason: String(reason || '') });
    self.ws = null;
    if (!self.closedByUser) self._scheduleReconnect();
  });
};

SocketProvider.prototype._scheduleReconnect = function () {
  var self = this;
  if (this.reconnectTimer || this.closedByUser) return;
  var delay = this.currentReconnectMs;
  this.currentReconnectMs = Math.min(this.currentReconnectMs * 2, this.maxReconnectMs);
  this.reconnectTimer = setTimeout(function () {
    self.reconnectTimer = null;
    try { self.connect(); } catch (e) { self._emit('error', e); self._scheduleReconnect(); }
  }, delay);
  if (this.reconnectTimer.unref) this.reconnectTimer.unref();
};

SocketProvider.prototype.sendJSON = function (payload) {
  if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return false;
  this.ws.send(JSON.stringify(payload));
  return true;
};

SocketProvider.prototype.close = function () {
  this.closedByUser = true;
  if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
  this.reconnectTimer = null;
  if (this.ws) {
    try { this.ws.close(); } catch (_) {}
  }
  this.ws = null;
};

SocketProvider.prototype.status = function () {
  var state = this.ws ? this.ws.readyState : WebSocket.CLOSED;
  return {
    provider: this.name,
    type: 'SOCKET',
    url: this.url,
    state: state,
    connected: state === WebSocket.OPEN
  };
};

module.exports = SocketProvider;
