# Changelog

## v1.7.4 - STABLE

- Correctif layout Trading IA : header agrandi, logo/navigation repositionnes.
- Scroll vertical desktop global pour acceder aux modules Mosaique.
- Synchronisation hauteur header avec overlays et mode Chart agrandi.
- Baseline GitHub et protocole de versionnage GitHub ajoutes.
- Patch source v1.7.3 -> v1.7.4 conserve dans `Update/`.
