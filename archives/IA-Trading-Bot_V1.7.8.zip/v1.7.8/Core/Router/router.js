'use strict';
/* TradingBot Unified Router + Communication Router v1.7.2
   Point d'entree unique navigateur : 127.0.0.1:8000
   - Coeur TradingBot v1.0 : 127.0.0.1:8001
   - Add-On Kraken : 127.0.0.1:8011
   - Indicator Engine : 127.0.0.1:8012
   Le coeur trading reste isole du moteur d'indicateurs.
*/
var http=require('http'),fs=require('fs'),path=require('path'),URL=require('url').URL,CommRouter=require('../Communication/communication_router_v1'),CP=require('../Communication/communication_protocol_v1');
var HOST='127.0.0.1';
var PORT=+(process.env.ROUTER_PORT||8000);
var CORE_HOST='127.0.0.1',CORE_PORT=+(process.env.CORE_PUBLIC_PORT||8001);
var KRAKEN_HOST='127.0.0.1',KRAKEN_PORT=+(process.env.KRAKEN_ADDON_PORT||8011);
var INDICATOR_HOST='127.0.0.1',INDICATOR_PORT=+(process.env.IATB_INDICATOR_PORT||8012);
var MARKET_DATA_HOST='127.0.0.1',MARKET_DATA_PORT=+(process.env.IATB_MARKET_DATA_PORT||8013);
var LIQUIDITY_HOST='127.0.0.1',LIQUIDITY_PORT=+(process.env.IATB_LIQUIDITY_PORT||8014);
var FUNDAMENTAL_HOST='127.0.0.1',FUNDAMENTAL_PORT=+(process.env.IATB_FUNDAMENTAL_PORT||8015);
var TRADING_ENGINE_HOST='127.0.0.1',TRADING_ENGINE_PORT=+(process.env.IATB_TRADING_ENGINE_PORT||8016);
var ROOT=__dirname,APP_ROOT=path.resolve(__dirname,'../..'),COMM=new CommRouter(APP_ROOT);
var COMM_MAX_BODY=512*1024;

function sendJson(res,code,obj){var b=Buffer.from(JSON.stringify(obj,null,2));res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Content-Length':b.length,'Cache-Control':'no-store'});res.end(b);}
function readJsonBody(req,limit,cb){var a=[],n=0,done=false;limit=limit||COMM_MAX_BODY;function fail(e){if(done)return;done=true;cb(e);}req.on('data',function(c){if(done)return;n+=c.length;if(n>limit){try{req.destroy();}catch(x){}return fail(new Error('COMM_PAYLOAD_TOO_LARGE'));}a.push(c);});req.on('end',function(){if(done)return;done=true;try{cb(null,JSON.parse(Buffer.concat(a).toString('utf8')||'{}'));}catch(e){cb(new Error('COMM_JSON_INVALID'));}});req.on('error',fail);}
function communicationRegister(req,res){var token=String(req.headers['x-iatb-cp-token']||'');if(!COMM.verifyToken(token))return sendJson(res,403,{ok:false,error:'CP_AUTH_FAILED'});readJsonBody(req,131072,function(e,b){if(e)return sendJson(res,400,{ok:false,error:e.message});try{var x=COMM.register(b);sendJson(res,200,{ok:true,protocol:CP.PROTOCOL,engine:{id:x.id,label:x.label,port:x.port,capabilities:x.capabilities,events:x.events||[],lastSeen:x.lastSeen}});}catch(er){sendJson(res,400,{ok:false,error:er.message});}});}
function communicationRequest(req,res){var token=String(req.headers['x-iatb-cp-token']||'');if(!COMM.verifyToken(token))return sendJson(res,403,{ok:false,error:'CP_AUTH_FAILED'});readJsonBody(req,COMM_MAX_BODY,function(e,b){if(e)return sendJson(res,400,{ok:false,error:e.message});COMM.route(b,function(er,o){if(er)return sendJson(res,400,{ok:false,error:er.message,protocol:CP.PROTOCOL});sendJson(res,200,o);});});}
function communicationEvent(req,res){var token=String(req.headers['x-iatb-cp-token']||'');if(!COMM.verifyToken(token))return sendJson(res,403,{ok:false,error:'CP_AUTH_FAILED'});readJsonBody(req,COMM_MAX_BODY,function(e,b){if(e)return sendJson(res,400,{ok:false,error:e.message});try{var ev=COMM.publishEvent(b);sendJson(res,200,{ok:true,protocol:CP.PROTOCOL,event_id:ev.event_id,accepted:true});}catch(er){sendJson(res,400,{ok:false,error:er.message,protocol:CP.PROTOCOL});}});}
function communicationEvents(req,u,res){var token=String(req.headers['x-iatb-cp-token']||'');if(!COMM.verifyToken(token))return sendJson(res,403,{ok:false,error:'CP_AUTH_FAILED'});sendJson(res,200,COMM.listEvents({since:+u.searchParams.get('since')||0,limit:+u.searchParams.get('limit')||50,source:u.searchParams.get('source')||''}));}

function communicationCapabilities(req,res){var token=String(req.headers['x-iatb-cp-token']||'');if(!COMM.verifyToken(token))return sendJson(res,403,{ok:false,error:'CP_AUTH_FAILED'});sendJson(res,200,COMM.capabilities());}
function communicationPlanClient(req,res){var token=String(req.headers['x-iatb-cp-token']||'');if(!COMM.verifyToken(token))return sendJson(res,403,{ok:false,error:'CP_AUTH_FAILED'});readJsonBody(req,131072,function(e,b){if(e)return sendJson(res,400,{ok:false,error:e.message});try{sendJson(res,200,{ok:true,action:COMM.planClientAction(b.action,b.arguments||{},b.meta||{})});}catch(er){sendJson(res,400,{ok:false,error:er.message});}});}
function communicationAckClient(req,res){var token=String(req.headers['x-iatb-cp-token']||'');if(!COMM.verifyToken(token))return sendJson(res,403,{ok:false,error:'CP_AUTH_FAILED'});readJsonBody(req,131072,function(e,b){if(e)return sendJson(res,400,{ok:false,error:e.message});try{sendJson(res,200,{ok:true,ack:COMM.ackClientAction(b)});}catch(er){sendJson(res,400,{ok:false,error:er.message});}});}
function communicationRuntime(req,res){var token=String(req.headers['x-iatb-cp-token']||'');if(!COMM.verifyToken(token))return sendJson(res,403,{ok:false,error:'CP_AUTH_FAILED'});sendJson(res,200,{ok:true,protocol:CP.PROTOCOL,runtime:COMM.runtimeSnapshot()});}
function communicationTest(res){var q=CP.makeRequest('indicator','indicator.list_capabilities',{},'summary');COMM.route(q,function(e,o){if(e)return sendJson(res,503,{ok:false,protocol:CP.PROTOCOL,error:e.message});sendJson(res,200,{ok:true,protocol:CP.PROTOCOL,message:'Communication Router -> Indicator Engine : OK',request_id:q.request_id,response:o});});}
function proxyError(res,label,err){if(res.headersSent){try{res.end();}catch(e){}return;}sendJson(res,503,{ok:false,service:label,error:label+' indisponible',detail:String(err&&err.message||err||'connexion impossible')});}
function copyHeaders(src){var h={};Object.keys(src||{}).forEach(function(k){if(k.toLowerCase()==='host'||k.toLowerCase()==='connection')return;h[k]=src[k];});return h;}
function responseHeaders(h){var out={};Object.keys(h||{}).forEach(function(k){var l=k.toLowerCase();if(l==='connection'||l==='transfer-encoding'||l==='content-length')return;out[k]=h[k];});return out;}
function injectKrakenLink(html){return html;}
function proxy(req,res,targetHost,targetPort,targetPath,opts){opts=opts||{};var headers=copyHeaders(req.headers);headers.host=targetHost+':'+targetPort;var p=http.request({host:targetHost,port:targetPort,path:targetPath,method:req.method,headers:headers,timeout:15000},function(pr){var ct=String(pr.headers['content-type']||'');if(opts.injectHtml&&req.method==='GET'&&ct.indexOf('text/html')>=0){var chunks=[];pr.on('data',function(c){chunks.push(c);});pr.on('end',function(){var body=Buffer.concat(chunks).toString('utf8');body=injectKrakenLink(body);var rh=responseHeaders(pr.headers);rh['Content-Length']=Buffer.byteLength(body);res.writeHead(pr.statusCode||200,rh);res.end(body);});return;}var rh=responseHeaders(pr.headers);res.writeHead(pr.statusCode||200,rh);pr.pipe(res);});p.on('timeout',function(){p.destroy(new Error('timeout'));});p.on('error',function(e){proxyError(res,opts.label||'Service',e);});req.pipe(p);}
function internalJson(port,pathname,cb){var req=http.get({host:'127.0.0.1',port:port,path:pathname,timeout:12000},function(pr){var chunks=[];pr.on('data',function(c){chunks.push(c)});pr.on('end',function(){var txt=Buffer.concat(chunks).toString('utf8'),obj=null;try{obj=JSON.parse(txt)}catch(e){return cb(new Error('JSON interne invalide'))}if((pr.statusCode||500)>=400)return cb(new Error(obj.error||('HTTP '+pr.statusCode)));cb(null,obj)});});req.on('timeout',function(){req.destroy(new Error('timeout'))});req.on('error',cb)}
function krakenPair(sym){sym=String(sym||'XBTEUR').toUpperCase();var map={BTCEUR:'XBTEUR',BTCUSD:'XBTUSD',XBTEUR:'XBTEUR',XBTUSD:'XBTUSD',ETHEUR:'ETHEUR',ETHUSD:'ETHUSD',SOLEUR:'SOLEUR',SOLUSD:'SOLUSD'};return map[sym]||sym}
function krakenMinutes(tf){return {'1m':1,'5m':5,'15m':15,'30m':30,'1h':60,'4h':240,'1d':1440,'1w':10080}[String(tf||'1h')]||60}
function firstDataKey(o){var ks=Object.keys(o||{});for(var i=0;i<ks.length;i++)if(ks[i]!=='last'&&Array.isArray(o[ks[i]]))return ks[i];return''}
function krakenVolumeFromRow(x){if(!Array.isArray(x))return 0;var v;if(x.length>=7)v=+x[6];else if(x.length>=6)v=+x[5];else v=0;return isFinite(v)&&v>0?v:0}
function candleMs(x){var t=Array.isArray(x)?+x[0]:0;if(t>0&&t<1000000000000)t*=1000;return isFinite(t)?Math.round(t):0}
function bucketKey(ts,mins){var span=Math.max(1,+mins||1)*60000;return String(Math.floor(ts/span))}
function exchangeTicker(req,u,res){var ex=String(u.searchParams.get('exchange')||'GMX').toUpperCase(),sym=String(u.searchParams.get('symbol')||'BTCUSD').toUpperCase();if(ex!=='KRAKEN')return proxy(req,res,CORE_HOST,CORE_PORT,'/api/gmx/ticker?symbol='+encodeURIComponent(sym),{label:'GMX'});var pair=krakenPair(sym);internalJson(KRAKEN_PORT,'/ticker?pair='+encodeURIComponent(pair),function(e,o){if(e)return proxyError(res,'Kraken Add-On',e);var k=Object.keys(o||{})[0],t=k&&o[k],px=t&&t.c&&+t.c[0];if(!isFinite(px)||px<=0)return sendJson(res,502,{ok:false,error:'Ticker Kraken invalide'});sendJson(res,200,{ok:true,exchange:'KRAKEN',symbol:sym,pair:pair,price:px,rawPair:k})})}
function exchangeKlines(req,u,res){
 var ex=String(u.searchParams.get('exchange')||'GMX').toUpperCase(),
     sym=String(u.searchParams.get('symbol')||'BTCUSD').toUpperCase(),
     tf=String(u.searchParams.get('interval')||'1h'),
     limit=Math.max(20,Math.min(720,+u.searchParams.get('limit')||100));
 if(ex==='KRAKEN'){
   var pair=krakenPair(sym),mins=krakenMinutes(tf);
   return internalJson(KRAKEN_PORT,'/ohlc?pair='+encodeURIComponent(pair)+'&interval='+mins,function(e,o){
     if(e)return proxyError(res,'Kraken Add-On',e);
     var key=firstDataKey(o),rows=key?o[key]:[],byTime={},candles=[],positive=0;
     if(!Array.isArray(rows))rows=[];
     for(var i=0;i<rows.length;i++){
       var x=rows[i];if(!Array.isArray(x)||x.length<5)continue;
       var ts=candleMs(x),op=+x[1],hi=+x[2],lo=+x[3],cl=+x[4],vol=krakenVolumeFromRow(x);
       if(!ts||!isFinite(op)||!isFinite(hi)||!isFinite(lo)||!isFinite(cl))continue;
       if(vol>0)positive++;
       byTime[String(ts)]=[ts,op,hi,lo,cl,vol];
     }
     Object.keys(byTime).sort(function(a,b){return(+a)-(+b)}).forEach(function(k){candles.push(byTime[k])});
     if(candles.length>limit)candles=candles.slice(candles.length-limit);
     sendJson(res,200,{ok:true,exchange:'KRAKEN',symbol:sym,pair:pair,interval:tf,candles:candles,volumeAvailable:positive>0,volumeSource:'KRAKEN_NATIVE',volumePositiveRows:positive,timestampUnit:'ms'});
   });
 }
 /* GMX: conserve strictement les donnees natives du marche. Aucun proxy volume
    provenant d'un autre exchange n'est injecte. */
 var corePath='/api/market/klines?source=GMX&symbol='+encodeURIComponent(sym)+'&interval='+encodeURIComponent(tf)+'&limit='+limit;
 internalJson(CORE_PORT,corePath,function(e,g){
   if(e)return proxyError(res,'GMX',e);
   var gc=g&&Array.isArray(g.candles)?g.candles:[];
   sendJson(res,200,{ok:true,exchange:'GMX',source:'GMX',symbol:sym,interval:tf,candles:gc,volumeAvailable:!!(g&&g.volumeAvailable),volumeSource:g&&g.volumeSource||'NONE',priceSource:'GMX'});
 });
}
function probe(port,pathname,cb){var done=false,req=http.get({host:'127.0.0.1',port:port,path:pathname,timeout:1000},function(r){r.resume();r.on('end',function(){if(done)return;done=true;cb(null,r.statusCode);});});req.on('timeout',function(){req.destroy();});req.on('error',function(e){if(done)return;done=true;cb(e);});}
function routerHealth(res){probe(CORE_PORT,'/api/health',function(ec,cc){probe(KRAKEN_PORT,'/health',function(ek,kc){probe(INDICATOR_PORT,'/health',function(ei,ic){probe(MARKET_DATA_PORT,'/health',function(em,mc){probe(LIQUIDITY_PORT,'/health',function(el,lc){probe(FUNDAMENTAL_PORT,'/health',function(ef,fc){probe(TRADING_ENGINE_PORT,'/health',function(et,tc){sendJson(res,200,{ok:!ec&&!em&&!el&&!et,router:true,version:'1.7.7',communicationProtocol:'CP/1',pid:process.pid,host:HOST,port:PORT,core:{ok:!ec&&cc===200,port:CORE_PORT,status:cc||0,error:ec?ec.message:''},kraken:{ok:!ek&&kc===200,port:KRAKEN_PORT,status:kc||0,error:ek?ek.message:''},indicators:{ok:!ei&&ic===200,port:INDICATOR_PORT,status:ic||0,error:ei?ei.message:''},marketData:{ok:!em&&mc===200,port:MARKET_DATA_PORT,status:mc||0,error:em?em.message:''},liquidity:{ok:!el&&lc===200,port:LIQUIDITY_PORT,status:lc||0,error:el?el.message:''},fundamental:{ok:!ef&&fc===200,port:FUNDAMENTAL_PORT,status:fc||0,error:ef?ef.message:''},trading:{ok:!et&&tc===200,port:TRADING_ENGINE_PORT,status:tc||0,error:et?et.message:''}});});});});});});});});}
var server=http.createServer(function(req,res){var u=new URL(req.url,'http://'+HOST+':'+PORT),p=u.pathname;
 if(p==='/router-health')return routerHealth(res);
 if(req.method==='GET'&&p==='/communication-health')return COMM.health(function(e,o){if(e)return sendJson(res,503,{ok:false,error:e.message});sendJson(res,200,o);});
 if(req.method==='POST'&&p==='/communication-test')return communicationTest(res);
 if(req.method==='POST'&&p==='/communication/v1/register')return communicationRegister(req,res);
 if(req.method==='POST'&&p==='/communication/v1/request')return communicationRequest(req,res);
 if(req.method==='POST'&&p==='/communication/v1/event')return communicationEvent(req,res);
 if(req.method==='GET'&&p==='/communication/v1/events')return communicationEvents(req,u,res);
 if(req.method==='GET'&&p==='/communication/v1/capabilities')return communicationCapabilities(req,res);
 if(req.method==='POST'&&p==='/communication/v1/client/plan')return communicationPlanClient(req,res);
 if(req.method==='POST'&&p==='/communication/v1/client/ack')return communicationAckClient(req,res);
 if(req.method==='GET'&&p==='/communication/v1/runtime')return communicationRuntime(req,res);
 if((req.method==='GET'||req.method==='HEAD')&&p==='/kraken'){res.writeHead(302,{'Location':'/trading?exchange=KRAKEN','Cache-Control':'no-store'});return res.end();}
 if(req.method==='GET'&&p==='/router-api/exchange/ticker')return exchangeTicker(req,u,res);
 if(req.method==='GET'&&p==='/router-api/exchange/klines')return exchangeKlines(req,u,res);
 if(p.indexOf('/kraken-api/')===0){var sub=p.slice('/kraken-api'.length)||'/';return proxy(req,res,KRAKEN_HOST,KRAKEN_PORT,sub+u.search,{label:'Kraken Add-On'});}
 if(p==='/indicator-api'||p.indexOf('/indicator-api/')===0){var isub=p.slice('/indicator-api'.length)||'/';return proxy(req,res,INDICATOR_HOST,INDICATOR_PORT,isub+u.search,{label:'Indicator Engine'});}
 if(p==='/market-data'||p.indexOf('/market-data/')===0){var msub=p.slice('/market-data'.length)||'/';return proxy(req,res,MARKET_DATA_HOST,MARKET_DATA_PORT,msub+u.search,{label:'Market Data'});}
 if(p==='/liquidity-data'||p.indexOf('/liquidity-data/')===0){var lsub=p.slice('/liquidity-data'.length)||'/';return proxy(req,res,LIQUIDITY_HOST,LIQUIDITY_PORT,lsub+u.search,{label:'Liquidity Engine'});}
 return proxy(req,res,CORE_HOST,CORE_PORT,u.pathname+u.search,{label:'TradingBot Core',injectHtml:true});
});
server.on('error',function(e){console.error('TradingBot Router bind error:',e&&e.message||e);process.exit(13);});server.listen(PORT,HOST,function(){console.log('TradingBot Communication Router v1.7.7 : http://'+HOST+':'+PORT);
console.log('Communication Protocol: CP/1 (canal Supervisor authentifie)');console.log('Core interne      : http://'+CORE_HOST+':'+CORE_PORT);console.log('Kraken interne    : http://'+KRAKEN_HOST+':'+KRAKEN_PORT);console.log('Indicator Engine  : http://'+INDICATOR_HOST+':'+INDICATOR_PORT);console.log('Market Data       : http://'+MARKET_DATA_HOST+':'+MARKET_DATA_PORT);console.log('Liquidity Engine  : http://'+LIQUIDITY_HOST+':'+LIQUIDITY_PORT);
console.log('Fundamental Engine: http://'+FUNDAMENTAL_HOST+':'+FUNDAMENTAL_PORT);console.log('Trading Engine    : http://'+TRADING_ENGINE_HOST+':'+TRADING_ENGINE_PORT);});
function stop(){server.close(function(){process.exit(0);});setTimeout(function(){process.exit(0);},1200);}
process.on('SIGINT',stop);process.on('SIGTERM',stop);
